1. Install Python 3.8 version
2. Install django rest framework using command - pip install django 
pip install djangorestframework
3. Install pycharm IDE and browse for the django project. virtual environment is created here by pycharm IDE.
4. After project is imported run the server using command - python manage.py runserver
5. Install Postman and make sure your local server is running after step 4.
6. That's All! Now you can put this  http://127.0.0.1:8000/WordConverterApp/ in Postman Request area.
i.) For GET /identity use this - http://127.0.0.1:8000/WordConverterApp/identity

ii.) For POST /convert use this - http://127.0.0.1:8000/WordConverterApp/convert
and Add this in "Body" part
{"value" : 45}
- Output will be like below :
[{"value": 45},{"value_in_words": "forty five "}]

Note :
- Make Sure you have djangorestframework correctly installed in system.
- I have supported GET method for /identity and POST for /convert, If you use vice-versa then it will show Method Not Supported error.
- If integer is greater than 999 trillion. It will return "400 Bad Request"
- String/Float/Negative integer, It will return "400 Bad Request"
- POST or GET for any other url will return "404 NOT FOUND"
