
class ConverterClass:
    def convertIntToWord(n):
        if n == 0:
            return "Zero"

        denominations = [1000000000000, 1000000000, 1000000, 1000, 100]
        stringArray = ["trillion ", "billion ", "million ", "thousand ", "hundred "]
        wordString = ""
        i = 0
        for denom in denominations:
            if n >= denom:
                wordString += numToWords(n / denom) + stringArray[i]
                n = int(n % denominations[i])
            i = i + 1
        if n > 0 and n < 100:
            wordString += numToWords(int(n))

        return wordString

def numToWords(n):
    str = ""
    if n >= 100:
        str += one[int(n / 100)] + "Hundred "
        n = int(n % 100)
    if n > 19:
        str += ten[int(n / 10)] + one[int(n % 10)]
    else:
        str += one[int(n)]
    return str

one = ["", "one ", "two ", "three ", "four ",
           "five ", "six ", "seven ", "eight ",
           "nine ", "ten ", "eleven ", "twelve ",
           "thirteen ", "fourteen ", "fifteen ",
           "sixteen ", "seventeen ", "eighteen ",
           "nineteen "]
ten = ["", "", "twenty ", "thirty ", "forty ",
           "fifty ", "sixty ", "seventy ", "eighty ",
           "ninety "]