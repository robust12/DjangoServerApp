from django.http import HttpResponse
import json
from rest_framework import status
from django.views.decorators.http import require_http_methods
from WordConverterApp.ConverterClass import ConverterClass


def index(request):
    return HttpResponse("Hello. You're at the Default index page.")

@require_http_methods(["GET"])
def identity_method(request):
    content = {'server_name' : 'Jitendra Mohan Prasad'}
    response = json.dumps([{status.HTTP_200_OK : content}])
    return HttpResponse(response, content_type='text/json')


@require_http_methods(["POST"])
def convert_method(request):
    received_json_data = json.loads(request.body)
    originalIntegerValue = received_json_data['value']
    maxLimit = 1000000000000000
    if isinstance(originalIntegerValue, int) == False or originalIntegerValue < 0 or \
            originalIntegerValue >= maxLimit:
        return HttpResponse(status=status.HTTP_400_BAD_REQUEST)

    wordsString = ConverterClass.convertIntToWord(originalIntegerValue)
    response = json.dumps([{"value" : originalIntegerValue}, {'value_in_words' : wordsString}])
    return HttpResponse(response, content_type='text/json')


def errorMethod(request, any_name):
    return HttpResponse(status=status.HTTP_404_NOT_FOUND)