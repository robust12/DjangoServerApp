from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('identity', views.identity_method),
    path('convert', views.convert_method),
    path('<str:any_name>', views.errorMethod)
]