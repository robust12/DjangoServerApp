from django.contrib import admin
#from .models import employee

#admin.site.register(employee)
# Register your models here.
