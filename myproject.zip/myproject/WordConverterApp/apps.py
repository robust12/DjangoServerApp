from django.apps import AppConfig


class WordconverterappConfig(AppConfig):
    name = 'WordConverterApp'
